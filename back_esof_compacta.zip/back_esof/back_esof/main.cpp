#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <algorithm> // Necessário para limpar espaços e substituir virgulas
#include <jdbc/mysql_driver.h>
#include <jdbc/mysql_connection.h>
#include <jdbc/cppconn/prepared_statement.h>
#include <jdbc/cppconn/resultset.h>

using namespace std;

struct Produto {
    string codigo;
    string nome;
    long double quantidade;
    double preco_custo;
};

vector<Produto> estoque;
string nomeArquivo = "estoque_material.csv";

// --- NOVA FUNÇÃO: BLINDAGEM DE ENTRADA ---
// Lê um número garantindo que não trave com letras, espaços ou vírgulas
long double lerLongDoubleSeguro(string mensagem) {
    string entrada;
    double numero = 0.0;
    bool valido = false;

    do {
        cout << mensagem;
        getline(cin, entrada);

        // 1. Remove espaços (ex: "10 000" vira "10000")
        entrada.erase(remove(entrada.begin(), entrada.end(), ' '), entrada.end());

        // 2. Troca vírgula por ponto (ex: "10,50" vira "10.50")
        replace(entrada.begin(), entrada.end(), ',', '.');

        // Se estiver vazio, pede de novo
        if (entrada.empty()) continue;

        try {
            size_t processado;
            numero = stold(entrada, &processado); // Tenta converter

            // Verifica se sobrou lixo (ex: "10abc")
            if (processado == entrada.length()) {
                valido = true;
            } else {
                cout << "[ERRO] Digite apenas numeros validos!\n";
            }
        } catch (...) {
            cout << "[ERRO] Entrada invalida. Tente novamente.\n";
        }
    } while (!valido);

    return numero;
}

void salvarEstoque() {
    ofstream arquivo(nomeArquivo);
    arquivo << "CODIGO;NOME;QUANTIDADE;PRECO_CUSTO;TOTAL_INVESTIDO\n";
    for (const auto& p : estoque) {
        arquivo << p.codigo << ";"
                << p.nome << ";"
                << p.quantidade << ";"
                << fixed << setprecision(2) << p.preco_custo << ";"
                << (p.quantidade * p.preco_custo) << "\n";
    }
    arquivo.close();
    cout << "\n[!] Dados salvos com sucesso.\n";
}

void carregarEstoque() {
    ifstream arquivo(nomeArquivo);
    if (!arquivo.is_open()) return;

    string linha;
    getline(arquivo, linha); // Pula o cabeçalho

    while (getline(arquivo, linha)) {
        stringstream ss(linha);
        Produto p;
        string qtdStr, precoStr;

        getline(ss, p.codigo, ';');
        getline(ss, p.nome, ';');
        getline(ss, qtdStr, ';');
        getline(ss, precoStr, ';');

        if(!p.codigo.empty()) {
            // --- AQUI ESTA O TRY-CATCH ---
            // Se o Excel tiver erro (ex: texto onde deveria ser numero), ele ignora a linha e nao fecha o programa
            try {
                p.quantidade = stold(qtdStr);
                p.preco_custo = stod(precoStr);
                estoque.push_back(p);
            } catch (...) {
                cout << "[AVISO] Erro ao ler produto '" << p.nome << "'. Linha ignorada/corrompida.\n";
            }
        }
    }
    arquivo.close();
}

int buscarProduto(string codigo) {
    for (int i = 0; i < estoque.size(); i++) {
        if (estoque[i].codigo == codigo) {
            return i;
        }
    }
    return -1;
}

void entradaSaidaEstoque() {
    string codigo;
    cout << "\n--- MOVIMENTACAO (Use o Leitor ou Digite) ---\n";
    cout << "Codigo do produto: ";
    cin >> codigo;
    cin.ignore(); // Limpa o buffer para o próximo getline funcionar

    int index = buscarProduto(codigo);

    // --- CASO 1: PRODUTO NOVO ---
    if (index == -1) {
        cout << "Produto nao cadastrado. Cadastrar agora? (1-Sim / 0-Nao): ";
        string opStr;
        getline(cin, opStr); // Lê como string para não travar

        if (opStr == "1") {
            Produto p;
            p.codigo = codigo;

            cout << "Nome do Material: ";
            getline(cin, p.nome);

            // Usa a função segura (convertendo double para int na quantidade)
            p.quantidade = lerLongDoubleSeguro("Quantidade inicial: ");
            long double qtd = lerLongDoubleSeguro("Quantidade a movimentar: ");
            p.preco_custo = lerLongDoubleSeguro("Preco de Custo (unidade): ");

            estoque.push_back(p);
            cout << "Produto cadastrado!\n";
            salvarEstoque();
        }

    // --- CASO 2: PRODUTO JA EXISTE ---
    } else {
        cout << "\n--------------------------------\n";
        cout << "Produto: " << estoque[index].nome << "\n";
        cout << "Estoque Atual: " << estoque[index].quantidade << "\n";
        cout << "Preco: R$ " << fixed << setprecision(2) << estoque[index].preco_custo << "\n";
        cout << "--------------------------------\n";

        cout << "O que deseja fazer?\n";
        cout << "1 - Alterar Quantidade (Entrada/Saida)\n";
        cout << "2 - DELETAR Produto do Sistema\n";
        cout << "0 - Cancelar\n";

        int acao = (int)lerLongDoubleSeguro("Opcao: ");

        if (acao == 1) {
            // --- ALTERAR QUANTIDADE ---
            cout << "Digite valor positivo para adicionar ou negativo para remover (ex: -5).\n";
            int qtd = (int)lerLongDoubleSeguro("Quantidade a movimentar: ");

            // Validação de estoque negativo
            if (estoque[index].quantidade + qtd < 0) {
                cout << "\n[ERRO] Operacao cancelada! Estoque ficaria negativo.\n";
            } else {
                estoque[index].quantidade += qtd;
                cout << "Sucesso! Novo estoque: " << estoque[index].quantidade << "\n";
                salvarEstoque();
            }

        } else if (acao == 2) {
            // --- DELETAR ---
            cout << "ATENCAO: Tem certeza que deseja apagar '" << estoque[index].nome << "'? (1-Sim / 0-Nao): ";
            int confirma = (int)lerLongDoubleSeguro(""); // Lê confirmação

            if (confirma == 1) {
                estoque.erase(estoque.begin() + index);
                cout << "Produto removido permanentemente.\n";
                salvarEstoque();
            }
        }
    }
}

void listarEstoque() {
    cout << "\n--- ESTOQUE ATUAL ---\n";
    if (estoque.empty()) {
        cout << "(Estoque vazio)\n";
        return;
    }

    // Cabeçalho bonito
    cout << left << setw(10) << "CODIGO"
         << left << setw(20) << "NOME"
         << right << setw(10) << "QTD"
         << right << setw(15) << "PRECO(R$)" << endl;
    cout << "--------------------------------------------------------\n";

    for (const auto& p : estoque) {
        cout << left << setw(10) << p.codigo
             << left << setw(20) << p.nome.substr(0, 19) // Corta nome longo
             << right << setw(10) << p.quantidade
             << right << setw(15) << fixed << setprecision(2) << p.preco_custo << "\n";
    }
}

int main() {
    carregarEstoque();
    int opcao;

    do {
        cout << "\n=== CONTROLE DE ESTOQUE - MATERIAL DE CONSTRUCAO ===\n";
        cout << "1. Escanear Produto / Gerenciar\n";
        cout << "2. Listar Tudo\n";
        cout << "3. Sair\n";

        // Usa lerLongDoubleSeguro para o menu também (evita crash se digitar letra)
        opcao = (int)lerLongDoubleSeguro("Opcao: ");

        if (opcao == 1) {
            entradaSaidaEstoque();
        } else if (opcao == 2) {
            listarEstoque();
        }

    } while (opcao != 3);

    return 0;
}
